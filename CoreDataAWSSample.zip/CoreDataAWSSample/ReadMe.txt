1. Need to include following framework:

 a) AWSDynamoDB.framework
 b) AWSRuntime.framework
 c) AWSPersistence.framework
 d) CoreData.framework
 

2. May need to change the ACCESS_KEY_ID and SECRET_KEY to access Amazon DynamoDB in DEMOViewController.h

It is very simple example using amazon dynamodb in our ios project. 
Here we can add "Name" and "Location" for a person and it directly store in amazon server. USING "EDIT" option we can delete a person from db present in server.