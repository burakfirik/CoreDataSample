//
//  Company.h
//  coredatasample
//
//  Created by Aditya Narayan on 1/25/14.
//  Copyright (c) 2014 Aditya. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface Company : NSManagedObject

@property (nonatomic, retain) NSString * companyName;

@end
