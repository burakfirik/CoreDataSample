//
//  Company.m
//  coredatasample
//
//  Created by Aditya Narayan on 1/25/14.
//  Copyright (c) 2014 Aditya. All rights reserved.
//

#import "Company.h"


@implementation Company

@dynamic companyName;

@end
