Core Data is a powerful unified framework Provided by Apple for persisting data in the applications. 
It is cheap in terms of processes usage, and relationship between data can also be maintained 
easily.

Need to include CoreData.framework.
It is the project, which use core data for store values though the program is not running. If you run the project later, you can see all data intact. 
In this application there are two text field for taking input from user
    1. Name
    2. Address
    
We also can delete person using "Edit" button.
