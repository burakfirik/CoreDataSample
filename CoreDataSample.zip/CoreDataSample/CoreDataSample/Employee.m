//
//  Employee.m
//  CoreDataSample
//
//  Created by Aditya on 07/11/13.
//  Copyright (c) 2013 Aditya. All rights reserved.
//

#import "Employee.h"


@implementation Employee

@dynamic emp_id;
@dynamic emp_location;
@dynamic emp_name;

@end
